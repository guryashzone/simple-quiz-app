var maths_questions = [
  {
    "no": 1,
    "question": "What is 7 + 8?",
    "option_1": "13",
    "option_2": "15",
    "option_3": "14",
    "option_4": "16",
    "correct_option": 2
  },
  {
    "no": 2,
    "question": "What is 15 - 7?",
    "option_1": "7",
    "option_2": "8",
    "option_3": "9",
    "option_4": "10",
    "correct_option": 2
  },
  {
    "no": 3,
    "question": "What is 9 * 6?",
    "option_1": "54",
    "option_2": "56",
    "option_3": "52",
    "option_4": "58",
    "correct_option": 1
  },
  {
    "no": 4,
    "question": "Solve for z: 4z + 2 = 18",
    "option_1": "3",
    "option_2": "4",
    "option_3": "5",
    "option_4": "6",
    "correct_option": 3
  },
  {
    "no": 5,
    "question": "What is the value of y if y/3 = 6?",
    "option_1": "16",
    "option_2": "18",
    "option_3": "20",
    "option_4": "22",
    "correct_option": 2
  },
  {
    "no": 6,
    "question": "Solve for x: 7x - 5 = 9",
    "option_1": "2",
    "option_2": "3",
    "option_3": "4",
    "option_4": "5",
    "correct_option": 3
  },
  {
    "no": 7,
    "question": "What is the volume of a rectangular prism with length 4, width 3, and height 2?",
    "option_1": "24",
    "option_2": "28",
    "option_3": "30",
    "option_4": "32",
    "correct_option": 1
  },
  {
    "no": 8,
    "question": "What is the length of the diagonal of a square with side length 5?",
    "option_1": "5√2",
    "option_2": "6√2",
    "option_3": "7√2",
    "option_4": "8√2",
    "correct_option": 1
  },
  {
    "no": 9,
    "question": "What is the area of an equilateral triangle with side length 6?",
    "option_1": "18√3",
    "option_2": "12√3",
    "option_3": "9√3",
    "option_4": "6√3",
    "correct_option": 3
  },
  {
    "no": 10,
    "question": "What is the measure of each interior angle in a regular hexagon?",
    "option_1": "120°",
    "option_2": "130°",
    "option_3": "140°",
    "option_4": "150°",
    "correct_option": 1
  }
];