var general_knowledge_sports_questions = [
  {
    "no": 1,
    "question": "In cricket, what is the term for a bowler taking three wickets in three consecutive deliveries?",
    "option_1": "Double Hat-trick",
    "option_2": "Three peat",
    "option_3": "Hattrick",
    "option_4": "Triple play",
    "correct_option": 3
  },
  {
    "no": 2,
    "question": "Which country has won the most FIFA World Cup titles?",
    "option_1": "Argentina",
    "option_2": "Brazil",
    "option_3": "Germany",
    "option_4": "Italy",
    "correct_option": 1
  },
  {
    "no": 3,
    "question": "When were the first modern Olympics Games held?",
    "option_1": "1900",
    "option_2": "1904",
    "option_3": "1896",
    "option_4": "1912",
    "correct_option": 3
  },
  {
    "no": 4,
    "question": "Which Tennis player has won the most Grand Slam?",
    "option_1": "Rafael Nadal",
    "option_2": "Novak Djokovic",
    "option_3": "Roger Federer",
    "option_4": "Pete Sampras",
    "correct_option": 2
  },
  {
    "no": 5,
    "question": "Which country has won the most Olympic gold in hockey?",
    "option_1": "Netherlands",
    "option_2": "Pakistan",
    "option_3": "Australia",
    "option_4": "India",
    "correct_option": 4
  },
  {
    "no": 6,
    "question": "Who is known as the 'Lightning Bolt' in athletics?",
    "option_1": "Michael Jordan",
    "option_2": "Carl Lewis",
    "option_3": "Cristiano Ronaldo",
    "option_4": "Usain Bolt",
    "correct_option": 4
  },
  {
    "no": 7,
    "question": "In which sport do teams compete for the Stanley Cup?",
    "option_1": "Football",
    "option_2": "Baseball",
    "option_3": "Ice Hockey",
    "option_4": "Cricket",
    "correct_option": 3
  },
  {
    "no": 8,
    "question": "Which country hosted the 2016 Summer Olympics?",
    "option_1": "China",
    "option_2": "Brazil",
    "option_3": "United Kingdom",
    "option_4": "France",
    "correct_option": 2
  },
  {
    "no": 9,
    "question": "Which country won the Cricket World Cup in 2024",
    "option_1": "England",
    "option_2": "New Zealand",
    "option_3": "Australia",
    "option_4": "India",
    "correct_option": 4
  },
  {
    "no": 10,
    "question": "In which sport would you find the terms : checkmate and stalemate?",
    "option_1": "Chess",
    "option_2": "Wrestling",
    "option_3": "Boxing",
    "option_4": "Wrestling",
    "correct_option": 1
  }
];