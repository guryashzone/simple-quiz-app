

var general_knowledge_world_questions = [
  {
    "no": 1,
    "question": "What is the capital city of Canada?",
    "option_1": "Toronto",
    "option_2": "Vancouver",
    "option_3": "Ottawa",
    "option_4": "Montreal",
    "correct_option": 3
  },
  {
    "no": 2,
    "question": "Which country is known as the Land of the Rising Sun?",
    "option_1": "China",
    "option_2": "Japan",
    "option_3": "South Korea",
    "option_4": "Thailand",
    "correct_option": 2
  },
  {
    "no": 3,
    "question": "What is the largest ocean on Earth?",
    "option_1": "Atlantic Ocean",
    "option_2": "Indian Ocean",
    "option_3": "Artic Ocean",
    "option_4": "Pacific Ocean",
    "correct_option": 4
  },
  {
    "no": 4,
    "question": "Which planet is known as the 'Morning Sun'?",
    "option_1": "Mercury",
    "option_2": "Venus",
    "option_3": "Mars",
    "option_4": "Jupiter",
    "correct_option": 2
  },
  {
    "no": 5,
    "question": "Who wrote the famous novel '1984'?",
    "option_1": "Aldous Huxley",
    "option_2": "George Orwell",
    "option_3": "J.K Rowling",
    "option_4": "Mark Twain",
    "correct_option": 2
  },
  {
    "no": 6,
    "question": "In which year did World War I begin?",
    "option_1": "1912",
    "option_2": "1914",
    "option_3": "1916",
    "option_4": "1918",
    "correct_option": 2
  },
  {
    "no": 7,
    "question": "Which continent is known as the 'Frozen Continent'?",
    "option_1": "Asia",
    "option_2": "Europe",
    "option_3": "Antartica",
    "option_4": "North America",
    "correct_option": 3
  },
  {
    "no": 8,
    "question": "What is the main ingredient in traditional Japanese miso soup?",
    "option_1": "Rice",
    "option_2": "Soyabean Paste",
    "option_3": "Fish",
    "option_4": "Tofu",
    "correct_option": 2
  },
  {
    "no": 9,
    "question": "Which European country is famous for its fjords?",
    "option_1": "Sweden",
    "option_2": "Finland",
    "option_3": "Norway",
    "option_4": "Denmark",
    "correct_option": 3
  },
  {
    "no": 10,
    "question": "What is the smallest independent country on Earth by population?",
    "option_1": "Monaco",
    "option_2": "Nauru",
    "option_3": "San Marino",
    "option_4": "Vatican City",
    "correct_option": 4
  }
];