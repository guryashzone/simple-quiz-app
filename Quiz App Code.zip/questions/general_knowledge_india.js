var general_knowledge_india_questions = [
  {
    "no": 1,
    "question": "Which Indian state has the highest literacy rate ?",
    "option_1": "Kerala",
    "option_2": "Tamil Nadu",
    "option_3": "Maharashtra",
    "option_4": "Punjab",
    "correct_option": 1
  },
  {
    "no": 2,
    "question": "The Ajanta and Ellora caves are located in which Indian state?",
    "option_1": "Rajasthan",
    "option_2": "Madhya Pradesh",
    "option_3": "Maharashtra",
    "option_4": "Gujarat",
    "correct_option": 3
  },
  {
    "no": 3,
    "question": "Who was the first Indian to win a Nobel Prize?",
    "option_1": "C.V. Raman",
    "option_2": "Rabindranath Tagore",
    "option_3": "Amartya Sen",
    "option_4": "Mother Teresa",
    "correct_option": 2
  },
  {
    "no": 4,
    "question": "Which Indian city is known as the 'City of Joy'?",
    "option_1": "Kolkata",
    "option_2": "Bangalore",
    "option_3": "Chennai",
    "option_4": "Mumbai",
    "correct_option": 1
  },
  {
    "no": 5,
    "question": "Who among the following was a famous Indian mathematician and astronomer?",
    "option_1": "Charaka",
    "option_2": "Chanakya",
    "option_3": "Shusruka",
    "option_4": "Aryabhata",
    "correct_option": 4
  },
  {
    "no": 6,
    "question": "In which year was the Indian Space Research Organisation (ISRO) established?",
    "option_1": "1959",
    "option_2": "1962",
    "option_3": "1972",
    "option_4": "1969",
    "correct_option": 4
  },
  {
    "no": 7,
    "question": "The Chipko Movement, associated with the protection of trees, originated in which Indian state?",
    "option_1": "Uttarakhand",
    "option_2": "Himachal Pradesh",
    "option_3": "Madhya Pradesh",
    "option_4": "Assam",
    "correct_option": 1
  },
  {
    "no": 8,
    "question": "Which Indian classical dance form originated in the state of Kerala?",
    "option_1": "Bharatnatyan",
    "option_2": "Kathak",
    "option_3": "Odissi",
    "option_4": "Kathakali",
    "correct_option": 4
  },
  {
    "no": 9,
    "question": "Who was the first Indian woman to win an Olympic medal?",
    "option_1": "P.T usha",
    "option_2": "Karnam Malleswari",
    "option_3": "Mary Kom",
    "option_4": "Saina Nehwal",
    "correct_option": 2
  },
  {
    "no": 10,
    "question": "Which Indian state is known as the 'Spice Garden of India'?",
    "option_1": "Karnataka",
    "option_2": "Tamil Nadu",
    "option_3": "Kerala",
    "option_4": "Andhra Pradesh",
    "correct_option": 3
  }
];